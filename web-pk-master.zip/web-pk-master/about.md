---
layout: default
---

# About Me

## Who Am I?

![](docs/images/avatar-photo.jpg)

*image_caption*

Write something about yourself, your course of study, why you took this Poly-Wide elective and what you hope to gain by the end of this module.
