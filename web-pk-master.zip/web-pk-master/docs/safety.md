---
layout: default
---

# Fablab Safety
## Introduction
Safety is paramount when working in our laboratories and workshop. Document the main points, information that you need to take note of when working in SP Fablab, what are some of the key **do**'s and **don't**'s that you need to take note of, what to do in case of emergencies.
