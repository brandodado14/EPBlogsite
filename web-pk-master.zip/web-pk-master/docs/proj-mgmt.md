---
layout: default
---

# Project Management
Notes about project management