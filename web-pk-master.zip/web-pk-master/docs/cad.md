---
layout: default
---

# Computer Aided Design
Notes on CAD

## Assignment

As a minimum, your should document the following:
- 2D raster: scale, crop, compress
- 2D vector: 
  - create (draw) objects using tools for 2D vector
  - convert from 2D raster to 2D vector
- 3D CAD software, e.g. Fusion 360
  - model a possible final project
